#pragma once

#pragma execution_character_set("utf-8")

#include <cstdio>
#include <cstddef>
#include <memory>
#include <mutex>
#include <vector>
#include <cstring>
#include <string>
#include <map>
#include <list>
#include <utility>
#include <cstdlib>
#include <iostream>
#include <ostream>
#include <sstream>
#include <istream>
#include <fstream>
#include <array>
#include <unordered_map>
#include <optional>
#include <set>
#include <algorithm>
#include <iomanip>


#if defined(WIN32) || defined(WIN64)
#define WINDOWS_PLATFROM

#define WIN32_LEAN_AND_MEAN
#endif

#include "Compute/ForwardDeclarations.h"
