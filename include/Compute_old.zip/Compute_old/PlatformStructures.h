#pragma once

//#include "Compute_Interface/PlatformStructures_private.h"
#include "Compute/PlatformStructures_private.h"